// Copyright (c) Rotorz Limited. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root.
#pragma strict

import System.Collections.Generic;

var wishlist:List.<String> = new List.<String>();
var points:List.<Vector2> = new List.<Vector2>();
